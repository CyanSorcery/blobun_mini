BLOBUN MINI
===============================================================================
Thank you for downloading Blobun Mini! We hope you enjoy it!
Unless of course, you've already played it. Then we hope you enjoyed it!

If you enjoyed this and want more, please look up Blobun! The full experience
features 140 unique puzzles over the span of 8 worlds.

CONTROLS:
Arrow keys: Move around
Z, C, N: Sprint
X, V, M: Undo
P: Pause

This game also supports gamepads!

CREDITS:
PICO-8 - Lexaloffle Games
Awe Mono, Hope Gold fonts - Eeve Somepx
PX9 Data Compression - zep
8-BIT Sound Effects¹ - Beep Yeah!

Sorry we couldn't credit you in the game itself, we ran out of tokens.

¹Sound effects manually recreated by Roxy.

LICENSE:
The game source code is available for download, and is released under
CC4-BY-NC-SA. All other program(s), code, sound effects, music, characters,
graphics, and puzzles (unless otherwise noted) are  Copyright 2024-2025
CyanSorcery All Rights Reserved.